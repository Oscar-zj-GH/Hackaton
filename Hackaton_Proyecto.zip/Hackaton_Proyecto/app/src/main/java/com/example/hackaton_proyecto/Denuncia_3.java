package com.example.hackaton_proyecto;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Denuncia_3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_denuncia3);
    }
}