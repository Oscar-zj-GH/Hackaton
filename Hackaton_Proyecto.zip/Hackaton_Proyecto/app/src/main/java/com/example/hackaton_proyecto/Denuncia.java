package com.example.hackaton_proyecto;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Denuncia extends AppCompatActivity {

    Button btn_aPrincipal;
    Button btn_infomacion_denuncia;
    Button btn_Denuncia_2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_denuncia);

        btn_aPrincipal = findViewById(R.id.btn_aPrincipal);
        btn_aPrincipal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent btn_aPrincipal = new Intent(Denuncia.this, Principal.class);
                startActivity(btn_aPrincipal);
            }
        });

        btn_infomacion_denuncia = findViewById(R.id.btn_infomacion_denuncia);
        btn_infomacion_denuncia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent btn_informacion_denuncia = new Intent(Denuncia.this, Informacion_Denuncia.class);
                startActivity(btn_informacion_denuncia);
            }
        });

        btn_Denuncia_2 = findViewById(R.id.btn_Denuncia_2);
        btn_Denuncia_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent btn_Denuncia_2 = new Intent(Denuncia.this, Denuncia_2.class);
                startActivity(btn_Denuncia_2);
            }
        });

    }
}