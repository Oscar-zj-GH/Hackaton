package com.example.hackaton_proyecto;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Denuncia_2 extends AppCompatActivity {

    Button btn_aDenuncia_3;
    Button btn_aDenuncia;
    Button btn_Denuncia_Informacion;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_denuncia2);

        btn_aDenuncia_3 = findViewById(R.id.btn_aDenuncia_3);
        btn_aDenuncia_3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent btn_aDenuncia_3 = new Intent(Denuncia_2.this, Denuncia_3.class);
                startActivity(btn_aDenuncia_3);
            }
        });

        btn_aDenuncia = findViewById(R.id.btn_aDenuncia);
        btn_aDenuncia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent btn_aDenuncia = new Intent(Denuncia_2.this, Denuncia.class);
                startActivity(btn_aDenuncia);
            }
        });

        btn_Denuncia_Informacion = findViewById(R.id.btn_infomacion_denuncia);
        btn_Denuncia_Informacion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent btn_Denuncia_Informacion = new Intent(Denuncia_2.this, Informacion_Denuncia.class);
                startActivity(btn_Denuncia_Informacion);
            }
        });
    }
}